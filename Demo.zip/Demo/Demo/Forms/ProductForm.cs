﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Demo
{
    public partial class ProductForm : Form
    {
        private int userRoleId;
        private DataBase db;

        public ProductForm(int roleId)
        {
            InitializeComponent();
            userRoleId = roleId;

            // Используем статический метод для получения строки подключения
            db = new DataBase();

            InitializeForm();
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            // Загружаем данные при старте формы
            LoadProductData();
        }

        private void InitializeForm()
        {
            // Устанавливаем видимость кнопок в зависимости от роли пользователя
            btnAdd.Visible = true;

            if (userRoleId == 1) // Роль администратора
            {
                btnEdit.Visible = true;
                btnDelete.Visible = true;
            }
            else // Роль пользователя
            {
                btnEdit.Visible = false;
                btnDelete.Visible = false;
            }
        }

        // Метод для загрузки данных в DataGridView с фильтрацией по запросу
        private void LoadProductData(string searchTerm = "")
        {
            // Получаем данные из базы данных с фильтрацией по строке поиска
            DataTable table = db.GetProducts(searchTerm);
            dataGridView1.DataSource = table;
        }

        // Метод для обработки ввода в поле поиска
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            // Получаем текст из поля поиска
            string searchTerm = txtSearch.Text.Trim();
            LoadProductData(searchTerm); 
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddForm addForm = new AddForm();
            if (addForm.ShowDialog() == DialogResult.OK) // Если добавление товара прошло успешно
            {
                LoadProductData(); // Обновляем таблицу товаров
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Получаем ID товара, который был выбран
                int selectedId = (int)dataGridView1.SelectedRows[0].Cells[0].Value;

                // Открываем форму редактирования, передаем ID товара для редактирования
                db = new DataBase();
                EditForm editForm = new EditForm(selectedId, db);

                // Если редактирование прошло успешно, обновляем данные
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadProductData(); // Обновляем таблицу товаров после редактирования
                }
            }
            else
            {
                MessageBox.Show("Выберите товар для редактирования.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Используем индекс столбца, если имя не соответствует
                int selectedId = (int)dataGridView1.SelectedRows[0].Cells[0].Value;

                // Запрашиваем подтверждение на удаление
                DialogResult result = MessageBox.Show("Вы уверены, что хотите удалить этот товар?", "Удаление", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    // Используем метод DeleteProduct из класса DataBase
                    bool isDeleted = db.DeleteProduct(selectedId);

                    if (isDeleted)
                    {
                        MessageBox.Show("Товар успешно удален!");
                        LoadProductData(); // Обновляем таблицу товаров
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при удалении товара.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите товар для удаления.");
            }
        }
    }
}
