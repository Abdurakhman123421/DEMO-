﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo
{
    public class DataBase
    {
        // Статическое поле для строки подключения
        private static string connectionString = "Data Source=DESKTOP-KG3VQL0;Initial Catalog=Magaz;Integrated Security=True";

        // Конструктор без параметров
        public DataBase() { }

        // Статический метод для получения строки подключения
        public static string GetConnectionString()
        {
            return connectionString;
        }

        public int ValidateUser(string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT ID_Роли FROM dbo.Клиент WHERE Логин = @username AND Пароль = @password";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        var result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            return (int)result; // Возвращаем ID_Роли
                        }
                        else
                        {
                            return -1; // Возвращаем -1, если пользователь не найден
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка подключения: " + ex.Message);
                    return -1;
                }
            }
        }

        // Пример другой функции, которая использует статическое подключение
        public bool AddProduct(string article, string name, string category, string brand, string animal, string description, string composition, int quantity, string unit, decimal price)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = "INSERT INTO Товар (Артикул, Название, Категория, Бренд, Животное, Описание, Состав, Колличество_за_ед, Единица, Стоимость) " + "VALUES (@article, @name, @category, @brand, @animal, @description, @composition, @quantity, @unit, @price)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@article", article);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@category", category);
                        cmd.Parameters.AddWithValue("@brand", brand);
                        cmd.Parameters.AddWithValue("@animal", animal);
                        cmd.Parameters.AddWithValue("@description", description);
                        cmd.Parameters.AddWithValue("@composition", composition);
                        cmd.Parameters.AddWithValue("@quantity", quantity);
                        cmd.Parameters.AddWithValue("@unit", unit);
                        cmd.Parameters.AddWithValue("@price", price);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        return rowsAffected > 0; // Возвращаем true, если товар успешно добавлен
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка добавления товара: " + ex.Message);
                    return false; // В случае ошибки, возвращаем false
                }
            }
        }

        public bool UpdateProduct(int productId, string article, string name, string category, string brand, string animal,
                                  string description, string composition, int quantity, string unit, decimal price)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE Товар SET Артикул = @article, Название = @name, Категория = @category, Бренд = @brand, " +
                                   "Животное = @animal, Описание = @description, Состав = @composition, Колличество_за_ед = @quantity, " +
                                   "Единица = @unit, Стоимость = @price WHERE Id_Товар = @productId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@article", article);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@category", category);
                        cmd.Parameters.AddWithValue("@brand", brand);
                        cmd.Parameters.AddWithValue("@animal", animal);
                        cmd.Parameters.AddWithValue("@description", description);
                        cmd.Parameters.AddWithValue("@composition", composition);
                        cmd.Parameters.AddWithValue("@quantity", quantity);
                        cmd.Parameters.AddWithValue("@unit", unit);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@productId", productId);

                        int rowsAffected = cmd.ExecuteNonQuery(); // Выполняем запрос на обновление
                        return rowsAffected > 0; // Если обновление прошло успешно, возвращаем true
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка редактирования товара: " + ex.Message);
                    return false;
                }
            }
        }
        public bool DeleteProduct(int productId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = "DELETE FROM Товар WHERE Id_Товар = @productId";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@productId", productId);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        return rowsAffected > 0; // Возвращаем true, если товар успешно удален
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка удаления товара: " + ex.Message);
                    return false; // В случае ошибки, возвращаем false
                }
            }
        }

        public DataTable GetProducts(string searchTerm = "")
        {
            DataTable table = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Если поисковая строка пустая, то выбираем все товары, иначе фильтруем по всем полям
                string query = string.IsNullOrEmpty(searchTerm)
                    ? "SELECT * FROM Товар"
                    : "SELECT * FROM Товар WHERE " +
                      "Артикул LIKE @searchTerm OR " +
                      "Название LIKE @searchTerm OR " +
                      "Категория LIKE @searchTerm OR " +
                      "Бренд LIKE @searchTerm OR " +
                      "Животное LIKE @searchTerm OR " +
                      "Описание LIKE @searchTerm OR " +
                      "Состав LIKE @searchTerm OR " +
                      "Единица LIKE @searchTerm"; 

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);

                // Если есть поисковая строка, добавляем параметр
                if (!string.IsNullOrEmpty(searchTerm))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@searchTerm", "%" + searchTerm + "%");
                }

                adapter.Fill(table);
            }
            return table;
        }
    }
}

